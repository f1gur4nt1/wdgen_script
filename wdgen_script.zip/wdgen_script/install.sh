






echo "Installing..."

apt-get install unstable-repo -y;apt-get install crunch -y

apt-get install wget -y

echo  "loc=$PWD" >> $HOME/.bashrc


echo 'alias wdscript="python $loc/.wd.py"' >> $HOME/.bashrc


echo "dir="\'$PWD\' > .wd.py


cat wdscript.py >> .wd.py


printf "Installed :D\n"


printf "If you want call the script, exit of terminal and back after, type wdscript\n"
