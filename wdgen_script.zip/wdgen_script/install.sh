






echo "Installing..."

apt-get install unstable-repo -y;apt-get install crunch -y

apt-get install wget -y

echo  "loc=$PWD" >> $HOME/.bashrc

alias wdscript="python3 $loc/.wd.py"

echo 'alias wdscript="python3 $loc/.wd.py"' >> $HOME/.bashrc


echo "dir="\'$PWD\' > .wd.py


cat wdscript.py >> .wd.py


printf "Installed :D\n"


printf "[ + ] If you want call the script, type bash. after it/ type wdscript\n"
