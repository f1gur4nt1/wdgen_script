

import os

esc_main=esc_scripts=esc_tool=None


print("""\033[1;33m                              _       _   
__      ____| | ___  ___ _ __(_)_ __ | |_ 
\ \ /\ / / _` |/ __|/ __| '__| | '_ \| __|
 \ V  V / (_| |\__ \ (__| |  | | |_) | |_ 
  \_/\_/ \__,_||___/\___|_|  |_| .__/ \__|
                                |_|        \033[1;32m

--> Created by @f1gur4nt1
--> A free and open source script
--> Version 1.1
\033[0;0m
""")


def main():
  print("\n\033[1;31m[\033[0;0m0\033[1;31m] EXIT\033[0;0m")
  print("\033[1;32m[\033[0;0m1\033[1;32m] SCRIPTS\033[0;0m")
  print("\033[1;32m[\033[0;0m2\033[1;32m] BRUTE FORCE TOOLS\033[0;0m")
  global esc_main
  esc_main = input("\n\033[1;33mmain_menu >> \033[0;0m")


def scripts():
  print("""\033[1;33m
    ___  ___ _ __(_)_ __ | |_ ___ 
   / __|/ __| '__| | '_ \| __/ __|
   \__ \ (__| |  | | |_) | |_\__ \
                                 
   |___/\___|_|  |_| .__/ \__|___/
                   |_|""")
  print("\n\033[1;32m[\033[0;0m1\033[1;32m] Wifi Auto Crunch (ANY)")
  print("[\033[0;0m2\033[1;32m] Cuppbr Wordlist Gerador (BR)")
  print("[\033[0;0m3\033[1;32m] Simple Wordlist Gerator (ANY)")
  print("[\033[0;0m4\033[1;32m] A good Wordlist Gerator++ (ANY)")
  print("[\033[0;0m5\033[1;32m] A Wordlist Gerator++ For hashes (ANY)")
  print("[\033[0;0m6\033[1;32m] Small_Wifi_Wdgen (ANY)")
  print("\033[1;31m[\033[0;0m0\033[1;31m] BACK")

  global esc_scripts
  esc_scripts=input("\n\033[1;33mscripts >> \033[0;0m")

def brute_tools():
  print("\n\033[1;32m[\033[0;0m1\033[1;32m] Install WIBR+ (ANDROID)")
  print("\033[1;31m[\033[0;0m0\033[1;31m] BACK")

  global esc_tool
  esc_tool = input("\n\033[1;33mbrute_tools >> \033[0;0m")


def install_wibr():
  if "Android" in os.popen("uname -a").read():
    os.system("am start -a android.intent.action.VIEW -d https://www.mediafire.com/file/hg2qvjnmirj2ane/WiBR+.apk/file")
    print("DOWNLOAD LINK: https://www.mediafire.com/file/hg2qvjnmirj2ane/WiBR+.apk/file")



main()


while True:

  escs_main = [None,"0","1","2"]
  escs_scripts = [None,"0","1","2","3","4","5","6"]

  if esc_main not in escs_main:
    esc_main = None
    print("\n\033[1;31m[!] Option Not Found!\n\033[0;0m")
    main()

  if esc_main == "0":
    exit()
  if esc_main == "1":
    esc_main = None
    scripts()
  if esc_main == "2":
    esc_main == None
    brute_tools()



  if esc_scripts not in escs_scripts:
    esc_main = None
    print("\n\033[1;31m[!] Option Not Found!\n\033[0;0m")
    main()

  if esc_scripts == "0":
    esc_scripts = None
    main()

  elif esc_scripts == "1":
    esc_scripts = None
    print("""\033[1;32m         WifiAutoCrunch is a Script Coded by @f1gur4nt1 that\n         make wordlists using a name base of the victim or a \n         place for help to crack a Wifi HandShake.\033[0;0m""")
    exec_autocrunch=input("\n\033[1;33mExecute?[Y/n] \033[0;0m")
    if exec_autocrunch == "n":
      scripts()
    else:
      os.system("python {}/scripts/WifiAutoCrunch/WifiAutoCrunch.py".format(dir))
      print("\n\033[1;32m[+] Wordlist gerated in this same directory\n\033[0;0m")
      scripts()

  elif esc_scripts == "2":
    esc_scripts = None
    print("\n\033[1;32m         Cuppbr é um script programado por @f1gur4nt1 que\n         faz perguntas como nome, sobrenome, parentes de\n         determinada pessoa e usa essas informacoes para\n         gerar uma wordlist.""")
    exec_cup=input("\n\033[1;33mExecutar?[S/n] \033[0;0m")
    if exec_cup == "n":
      scripts()
    else:
      print("\n\n\n")
      pwd = os.popen("pwd").read()
      os.system("python {}/scripts/cupbr/cupbr.py {}".format(dir,pwd[:-1]))
      print("\n\033[1;32m[+] Wordlist gerated in this same directory\n")
      scripts()

  elif esc_scripts == "3":
    esc_scripts = None
    print("\n\033[1;32m         Wdgen is a simple wordlist gerator Created by @f1gur4nt1.")
    exec_wdgen=input("\n\033[1;33mExecute?[Y/n] \033[0;0m")
    if exec_wdgen == "n":
      scripts()
    else:
      victim=input("\033[1;33mPut the middle word: \033[0;0m")
      os.system("python {}/scripts/wdgen/wdgen.py {}".format(dir,victim))
      print("\n \033[1;32m[+]Wordlist gerated in this same directory\033[0;0m\n")
      scripts()

  elif esc_scripts == "4":
    esc_scripts = None
    print("\033[1;32m           Wdgen++ is a simple wordlist gerator Created by \n           @f1gur4nt1 that create a useful wordlist for crack \n           the most hard passwords.\033[0;0m")
    exec_wdgenmoremore=input("\n\033[1;33mExecute[Y/n]: \033[0;0m")
    if exec_wdgenmoremore == "n":
      scripts()
    else:
      word=input("\n\033[1;33mPut any word: \033[0;0m")
      os.system("python {}/scripts/wdgen++/wdgen++.py {}".format(dir,word))
      print("\n \033[1;32m[+]Wordlist gerated in this same directory\n\033[0;0m")
      scripts()

  elif esc_scripts == "5":
    esc_scripts = None
    word=input("\n\033[1;33mPut any word: \033[0;0m")
    os.system("python {}/scripts/wdgen++_for_hasher/wdgen++for_hasher.py {}".format(dir,word))
    scripts()

  elif esc_scripts == "6":
    esc_scripts = None
    print("\033[1;32m           Small_Wifi_Wdgen Is a small wordlist gerator to do BruteForce with WIBR+ using a ANDROID Device.")
    exec_smallwifigen = input("\n\033[1;33mExecute[Y/n]: \033[0;0m")
    if exec_smallwifigen == "n":
      scripts()
    else:
      word=input("\n\033[1;33mPut any word: \033[0;0m")
      os.system("python {}/scripts/Small_Wifi_Wdgen/Small_Wifi_Wdgen.py {}".format(dir,word))
      print("\n\033[1;32m[+] Wordlist gerated in this same directory\n\033[0;0m")



  if esc_tool == "0":
    esc_tool = None
    main()

  if esc_tool == "1":
    esc_tool = None
    print("\033[1;32m           WIBR+ Is a ANDROID App Hacker Tool that do Brute Force in WIFI.")
    install_wibr = input("\n\033[1;33mInstall[Y/n]: \033[0;0m")
    if install_wibr == "n":
      install_wibr = None
    else:
      install_wibr = None
      if "Android" in os.popen("uname -a").read():
        os.popen("am start -a android.intent.action.VIEW -d https://www.sendspace.com/file/r430vp")
        print("DOWNLOAD LINK: https://www.sendspace.com/file/r430vp")
        brute_tools()
      else:
        print("\033[1;31m[!] Platform is not compatible!\033[0;0m")
        brute_tools()


