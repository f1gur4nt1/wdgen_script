
import sys

cpm = ["123","1234","12345","123456","2017","2018","2019","2020","2021","321","0123","01234","012345","4321"]

nome = sys.argv[1]

Nome = nome[:1].upper() + nome[1:]

NOME =  nome.upper()

w1 = open(nome+"1.txt","a")
w2 = open(Nome+"2.txt","a")
w3 = open(NOME+"3.txt","a")

for a in cpm:
  if len( nome+a ) >= 8:
    w1.write(nome+a+"\n")
    w2.write(Nome+a+"\n")
    w3.write(NOME+a+"\n")

  if len( nome+"@"+a ) >= 8:
    w1.write(nome+"@"+a+"\n")
    w2.write(Nome+"@"+a+"\n")
    w3.write(NOME+"@"+a+"\n")

  if len( nome+"#"+a ) >= 8:
    w1.write(nome+"#"+a+"\n")
    w2.write(Nome+"#"+a+"\n")
    w3.write(NOME+"#"+a+"\n")

  if len( nome+a+"@" ) >= 8:
    w1.write(nome+a+"@\n")
    w2.write(Nome+a+"@\n")
    w3.write(NOME+a+"@\n")

  if len( nome+a+"#" ) >= 8:
    w1.write(nome+a+"#\n")
    w2.write(Nome+a+"#\n")
    w3.write(NOME+a+"#\n")

  if len( nome+" "+a ) >= 8:
    w1.write(nome+" "+a+"\n")
    w2.write(Nome+" "+a+"\n")
    w3.write(NOME+" "+a+"\n")

w1.close()
w2.close()
w3.close()



